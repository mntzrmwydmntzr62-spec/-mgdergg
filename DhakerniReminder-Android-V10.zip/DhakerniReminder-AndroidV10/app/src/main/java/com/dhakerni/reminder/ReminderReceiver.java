package com.dhakerni.reminder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String ACTION_FIRE="com.dhakerni.reminder.FIRE";
    public static final String ACTION_STOP="com.dhakerni.reminder.STOP";
    @Override public void onReceive(Context context, Intent intent){
        String action=intent.getAction();
        if(ACTION_STOP.equals(action)){
            Intent s=new Intent(context,ReminderSpeakService.class).setAction(ACTION_STOP).putExtra("id",intent.getStringExtra("id"));
            context.startService(s); return;
        }
        if(ACTION_FIRE.equals(action)){
            String id=intent.getStringExtra("id");
            if(id==null)return;
            String[] v=ReminderStore.get(context,id); if(v==null)return;
            Intent s=new Intent(context,ReminderSpeakService.class).setAction(ACTION_FIRE).putExtra("id",id);
            if(Build.VERSION.SDK_INT>=26) context.startForegroundService(s); else context.startService(s);
        }
    }
}
