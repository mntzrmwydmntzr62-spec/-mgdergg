package com.dhakerni.reminder;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private SpeechRecognizer speech;
    private static final int REQ_NOTIFY=701;
    private static final int REQ_AUDIO=702;

    @Override protected void onCreate(Bundle b){ super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AndroidBridge(),"AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33) web.postDelayed(()->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFY),900);
    }

    public class AndroidBridge {
        @JavascriptInterface public boolean isAndroid(){return true;}
        @JavascriptInterface public void scheduleReminder(String id,long when,String text){ runOnUiThread(()->ReminderScheduler.schedule(MainActivity.this,id,when,text)); }
        @JavascriptInterface public void cancelReminder(String id){ runOnUiThread(()->ReminderScheduler.cancel(MainActivity.this,id)); }
        @JavascriptInterface public void syncReminder(String id,long when,String text){ runOnUiThread(()->ReminderScheduler.schedule(MainActivity.this,id,when,text)); }
        @JavascriptInterface public void enableNotifications(){
            runOnUiThread(()->{
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFY);
                openExactAlarmIfNeeded();
            });
        }
        @JavascriptInterface public void openExactAlarmSettings(){ runOnUiThread(MainActivity.this::openExactAlarmIfNeeded); }
        @JavascriptInterface public void startVoice(){ runOnUiThread(MainActivity.this::startVoiceInput); }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_AUDIO && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){ startVoiceInput(); }
    }

    private void openExactAlarmIfNeeded(){
        if(Build.VERSION.SDK_INT>=31){ AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(!am.canScheduleExactAlarms()){
            try{ Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM); i.setData(Uri.parse("package:"+getPackageName())); startActivity(i); }catch(Exception ignored){}
        }}
    }

    private void startVoiceInput(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO); return; }
        if(!SpeechRecognizer.isRecognitionAvailable(this)){ sendJs("window.nativeVoiceError && window.nativeVoiceError('unavailable')"); return; }
        if(speech!=null){speech.destroy(); speech=null;}
        speech=SpeechRecognizer.createSpeechRecognizer(this);
        speech.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){sendJs("window.nativeVoiceStatus&&window.nativeVoiceStatus('listening')");}
            public void onBeginningOfSpeech(){sendJs("window.nativeVoiceStatus&&window.nativeVoiceStatus('listening')");}
            public void onRmsChanged(float r){}
            public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){sendJs("window.nativeVoiceStatus&&window.nativeVoiceStatus('processing')");}
            public void onError(int e){sendJs("window.nativeVoiceError&&window.nativeVoiceError('error')");}
            public void onResults(Bundle r){ArrayList<String> a=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()){String t=a.get(0).replace("\\","\\\\").replace("'","\\'").replace("\n"," "); sendJs("window.nativeVoiceResult&&window.nativeVoiceResult('"+t+"')");} else sendJs("window.nativeVoiceError&&window.nativeVoiceError('no-speech')");}
            public void onPartialResults(Bundle r){ArrayList<String> a=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()){String t=a.get(0).replace("\\","\\\\").replace("'","\\'").replace("\n"," "); sendJs("window.nativeVoicePartial&&window.nativeVoicePartial('"+t+"')");}}
            public void onEvent(int t,Bundle p){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-IQ"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"ar-IQ"); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true); i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"تحدث الآن");
        speech.startListening(i);
    }
    private void sendJs(String js){ if(web!=null) web.post(()->web.evaluateJavascript(js,null)); }
    @Override protected void onDestroy(){ if(speech!=null)speech.destroy(); if(web!=null)web.destroy(); super.onDestroy(); }
}
