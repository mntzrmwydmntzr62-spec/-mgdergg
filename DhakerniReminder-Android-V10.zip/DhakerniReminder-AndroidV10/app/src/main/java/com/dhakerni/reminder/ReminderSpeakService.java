package com.dhakerni.reminder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class ReminderSpeakService extends Service {
    private static final String CHANNEL="reminders";
    private TextToSpeech tts;
    private String activeId;
    private String activeText;
    private final AtomicBoolean speaking=new AtomicBoolean(false);
    private final Handler handler=new Handler();
    private final Runnable repeat=new Runnable(){ public void run(){
        if(activeText==null)return;
        speak(activeText);
        handler.postDelayed(this,7000);
    }};

    @Override public void onCreate(){ super.onCreate(); createChannel();
        tts=new TextToSpeech(this,status->{ if(status==TextToSpeech.SUCCESS){ tts.setLanguage(new Locale("ar","IQ")); tts.setSpeechRate(.88f); } });
    }
    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){ NotificationChannel ch=new NotificationChannel(CHANNEL,"تذكيرات",NotificationManager.IMPORTANCE_HIGH); ch.setDescription("تنبيهات المواعيد"); ch.setSound(null,null); ch.enableVibration(true); getSystemService(NotificationManager.class).createNotificationChannel(ch); }
    }
    private Notification buildNotification(){
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("reminder_id",activeId);
        PendingIntent content=PendingIntent.getActivity(this,10,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent stop=new Intent(this,ReminderReceiver.class).setAction(ReminderReceiver.ACTION_STOP).putExtra("id",activeId);
        PendingIntent dismiss=PendingIntent.getBroadcast(this,20,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("🔔 ذكّرني").setContentText(activeText)
         .setStyle(new Notification.BigTextStyle().bigText(activeText)).setContentIntent(content).setOngoing(true).setAutoCancel(false)
         .addAction(new Notification.Action.Builder(null,"إيقاف",dismiss).build());
        return b.build();
    }
    private void speak(String text){
        if(tts==null || speaking.getAndSet(true))return;
        tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"reminder");
        handler.postDelayed(()->speaking.set(false),5000);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ReminderReceiver.ACTION_STOP.equals(intent.getAction())){ stopSelf(); return START_NOT_STICKY; }
        String id=intent==null?null:intent.getStringExtra("id");
        if(id==null)return START_NOT_STICKY;
        String[] v=ReminderStore.get(this,id); if(v==null)return START_NOT_STICKY;
        activeId=id;activeText=v[1];
        startForeground(1001,buildNotification());
        handler.removeCallbacks(repeat); handler.post(repeat);
        return START_NOT_STICKY;
    }
    @Override public void onDestroy(){ handler.removeCallbacks(repeat); if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){return null;}
}
