package com.dhakerni.reminder;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Map;

public final class ReminderStore {
    private static final String PREF = "native_reminders";
    private static final String SEP = "\u0001";
    private ReminderStore() {}
    private static SharedPreferences p(Context c){ return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    public static void put(Context c, String id, long when, String text){ p(c).edit().putString(id, when + SEP + text).apply(); }
    public static void remove(Context c, String id){ p(c).edit().remove(id).apply(); }
    public static Map<String, ?> all(Context c){ return p(c).getAll(); }
    public static String[] get(Context c, String id){
        String v=p(c).getString(id,null); if(v==null)return null;
        int i=v.indexOf(SEP); if(i<0)return null;
        return new String[]{v.substring(0,i),v.substring(i+1)};
    }
}
