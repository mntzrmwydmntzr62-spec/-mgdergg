package com.dhakerni.reminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Map;

public final class ReminderScheduler {
    private ReminderScheduler() {}
    private static PendingIntent pi(Context c,String id){
        Intent i=new Intent(c,ReminderReceiver.class).setAction(ReminderReceiver.ACTION_FIRE).putExtra("id",id);
        return PendingIntent.getBroadcast(c, Math.abs(id.hashCode()), i, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedule(Context c,String id,long when,String text){
        if(when<=System.currentTimeMillis())return;
        ReminderStore.put(c,id,when,text);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p=pi(c,id);
        try{
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);
            } else if(Build.VERSION.SDK_INT>=23){
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);
            } else { am.setExact(AlarmManager.RTC_WAKEUP,when,p); }
        }catch(SecurityException e){ am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p); }
    }
    public static void cancel(Context c,String id){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pi(c,id)); ReminderStore.remove(c,id);
    }
    public static void rescheduleAll(Context c){
        long now=System.currentTimeMillis();
        for(Map.Entry<String,?> e:ReminderStore.all(c).entrySet()){
            if(!(e.getValue() instanceof String))continue;
            String[] v=ReminderStore.get(c,e.getKey());
            if(v==null)continue;
            long when; try{when=Long.parseLong(v[0]);}catch(Exception x){continue;}
            if(when>now)schedule(c,e.getKey(),when,v[1]); else ReminderStore.remove(c,e.getKey());
        }
    }
}
